# Silima Shop — site statique

Version 100 % statique du site : HTML, CSS et JavaScript, sans serveur ni base de données.
Conçue pour un hébergement gratuit sur **Vercel**. La commande se fait uniquement par
**WhatsApp** au **+225 07 88 88 03 07**.

---

## Mettre en ligne sur Vercel (10 minutes)

1. Créer un compte sur [vercel.com](https://vercel.com) (gratuit).
2. **Add New → Project → Deploy** puis glisser-déposer ce dossier, ou le pousser sur GitHub
   et l'importer.
3. Aucune commande de build n'est nécessaire : Vercel détecte un site statique.
   - Framework Preset : **Other**
   - Build Command : *(vide)*
   - Output Directory : *(vide, la racine)*
4. Déployer. Le site est en ligne sur `https://nom-du-projet.vercel.app`.

### Après la mise en ligne : remplacer l'adresse

Le domaine `silima-shop.vercel.app` est utilisé dans trois fichiers. Remplacez-le par votre
adresse réelle dès la première mise en ligne :

| Fichier | À modifier |
|---|---|
| `sitemap.xml` | toutes les balises `<loc>` |
| `robots.txt` | ligne `Sitemap:` |
| `index.html`, `produits.html`, `gros.html`, `a-propos.html`, `contact.html` | `<link rel="canonical">` et `og:image` |

Astuce : une recherche-remplacement de `https://silima-shop.vercel.app` par votre adresse
dans ces fichiers suffit.

---

## Ajouter ou modifier un produit

Tout se passe dans **`assets/products.js`**, aucun outil à installer.

```js
{
  slug: 'parure-jimmy-confort-blanc-casse',   // adresse de la fiche, sans espace ni accent
  name: 'Parure Jimmy « Confort » — blanc cassé',
  reference: 'DEMO-001',
  category: 'draps-de-lit',                    // doit exister dans CATEGORIES
  short: 'Parure de lit unie, coloris blanc cassé.',
  description: 'Texte de la fiche produit…',
  price: 18500,                                 // null → « Prix sur demande »
  sizes: ['2 places (140×190)'],
  images: ['sheets-offwhite', 'sheets-sand'],   // fichiers présents dans /img
  stock: 'disponible',                          // disponible | limite | rupture | indisponible
  featured: true,                               // visible sur la page d'accueil
  demo: true,                                   // affiche le repère « Démo »
}
```

### Ajouter des photos

1. Ouvrir l'image dans un éditeur et l'exporter en deux largeurs : **480 px** et **960 px**
   de large, format WebP.
2. Les nommer `mon-produit-480.webp` et `mon-produit-960.webp`.
3. Les placer dans `img/` et référencer `mon-produit` dans le champ `images`.

Le site affiche automatiquement la bonne taille selon l'écran. Une image pèse
idéalement moins de 120 Ko.

### Modifier le numéro WhatsApp

En haut de `assets/products.js` :

```js
whatsapp: '2250788880307',              // chiffres uniquement, sans + ni espaces
whatsappDisplay: '+225 07 88 88 03 07', // texte affiché sur le site
```

---

## Ce que fait le site

| Page | Contenu |
|---|---|
| `index.html` | accueil, catégories, produits mis en avant, étapes de commande |
| `produits.html` | catalogue avec recherche, filtres par catégorie, tri par prix |
| `produit.html?p=…` | fiche produit : galerie, tailles, quantité, deux boutons WhatsApp |
| `gros.html` | vente en gros, message WhatsApp dédié aux revendeurs |
| `a-propos.html` | présentation, sans fait inventé |
| `contact.html` | WhatsApp, téléphone, localisation |

- Les boutons « Commander » ouvrent WhatsApp avec un message déjà rédigé : nom du
  produit, référence, quantité, lien vers la fiche.
- Aucun prix n'est inventé : un produit sans prix affiche « Prix sur demande ».
- Aucune donnée n'est collectée, aucun cookie, aucun formulaire. Rien à déclarer côté
  vie privée au-delà de l'identité de la boutique.

## Limites de la version statique

Par rapport à la version complète (dossier `silima-shop/`), il n'y a pas :

- d'espace d'administration : les produits se modifient dans `assets/products.js` ;
- de demandes enregistrées : tout passe par WhatsApp, rien n'est archivé sur le site ;
- de stock automatique : le statut de chaque produit est écrit à la main.

Pour la version avec tableau de bord, base de données et suivi des demandes, utilisez le
dossier `silima-shop/` (Express + SQLite) déployé sur un hébergement avec disque
persistant.

## Vérifications effectuées

32 contrôles automatisés dans un navigateur mobile (390×844) : navigation, recherche,
filtres, fiches produit, galerie, quantité transmise dans le message WhatsApp, produit en
rupture, produit inexistant, menu mobile, absence de débordement horizontal, aucune erreur
JavaScript.

## Crédits photos

Photos de démonstration issues de Pexels et Unsplash (licences libres), à remplacer par les
photos réelles de la boutique. Détail : `CREDITS-PHOTOS.md`.
