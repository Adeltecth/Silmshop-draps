/* Silima Shop — logique du site statique (aucune dépendance, aucun serveur). */

const STOCK_LABELS = {
  disponible: 'Disponible',
  limite: 'Stock limité',
  rupture: 'Rupture de stock',
  indisponible: 'Indisponible',
};

const money = (value) =>
  value === null || value === undefined
    ? null
    : new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(value) + ' ' + SHOP.currency;

const productUrl = (slug) => `produit.html?p=${encodeURIComponent(slug)}`;
const absoluteUrl = (slug) => new URL(productUrl(slug), window.location.href).href;
const bySlug = (slug) => PRODUCTS.find((p) => p.slug === slug);
const categoryName = (id) => (CATEGORIES.find((c) => c.id === id) || {}).name || 'Textiles de maison';
const orderable = (stock) => stock === 'disponible' || stock === 'limite';

/* ---------------------------------------------------------------- WhatsApp */

function whatsapp(message) {
  return `https://wa.me/${SHOP.whatsapp}?text=${encodeURIComponent(message)}`;
}

function productMessage(product, quantity = 1) {
  return [
    `Bonjour ${SHOP.name}, je souhaite commander ou obtenir des informations sur le produit ${product.name} (référence ${product.reference}), quantité ${quantity}.`,
    absoluteUrl(product.slug),
    'Pouvez-vous me confirmer le prix et la disponibilité ?',
  ].join('\n');
}

const generalMessage = () =>
  `Bonjour ${SHOP.name}, je souhaite obtenir des informations sur vos produits. Pouvez-vous me confirmer les modèles disponibles et leurs prix ?`;

const wholesaleMessage = () =>
  `Bonjour ${SHOP.name}, je suis commerçant / revendeur. Je souhaite connaître vos conditions pour un achat en gros : quantités possibles, prix applicables et disponibilité.`;

/* ------------------------------------------------------------------ Utils */

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'html') node.innerHTML = value;
    else node.setAttribute(key, value);
  }
  for (const child of [].concat(children)) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(child));
  }
  return node;
}

function imageTag(key, alt, opts = {}) {
  const img = el('img', {
    src: `img/${key}-480.webp`,
    srcset: `img/${key}-480.webp 480w, img/${key}-960.webp 960w`,
    sizes: opts.sizes || '(min-width: 1024px) 25vw, 46vw',
    alt,
    loading: opts.priority ? 'eager' : 'lazy',
    decoding: 'async',
    class: opts.class || '',
  });
  return img;
}

/* ----------------------------------------------------------------- Header */

function mountChrome() {
  const notice = document.getElementById('notice');
  if (notice) {
    if (SHOP.demoNotice) {
      notice.innerHTML = `<div class="notice"><p>${SHOP.demoNotice}</p><button type="button" aria-label="Masquer le bandeau" data-close-notice>&times;</button></div>`;
      notice.querySelector('[data-close-notice]').addEventListener('click', () => notice.remove());
    } else {
      notice.remove();
    }
  }

  const wa = document.querySelectorAll('[data-whatsapp="general"]');
  wa.forEach((a) => {
    a.href = whatsapp(generalMessage());
    a.target = '_blank';
    a.rel = 'noopener';
  });
  document.querySelectorAll('[data-whatsapp="wholesale"]').forEach((a) => {
    a.href = whatsapp(wholesaleMessage());
    a.target = '_blank';
    a.rel = 'noopener';
  });

  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  const burger = document.querySelector('[data-burger]');
  const menu = document.getElementById('menu');
  if (burger && menu) {
    burger.addEventListener('click', () => {
      const open = menu.hasAttribute('hidden');
      if (open) menu.removeAttribute('hidden');
      else menu.setAttribute('hidden', '');
      burger.setAttribute('aria-expanded', String(open));
    });
  }
}

/* ------------------------------------------------------------------ Cards */

function productCard(product) {
  const price = money(product.price);
  const badge =
    product.stock === 'disponible'
      ? null
      : el('span', { class: `chip chip-${product.stock}` }, STOCK_LABELS[product.stock]);

  const media = el('a', { href: productUrl(product.slug), class: 'card-media', 'aria-label': `Voir ${product.name}` }, [
    product.images && product.images[0]
      ? imageTag(product.images[0], `${product.name} — ${categoryName(product.category)}`)
      : el('div', { class: 'card-noimg' }, 'Photo à venir'),
  ]);

  const figure = el('div', { class: 'card-figure' }, [media]);
  if (badge) figure.append(el('div', { class: 'card-badge' }, badge));
  if (product.demo) figure.append(el('span', { class: 'card-demo' }, 'Démo'));

  const canOrder = orderable(product.stock);
  const action = el(
    'a',
    {
      class: canOrder ? 'btn btn-wa btn-block' : 'btn btn-ghost btn-block',
      href: whatsapp(productMessage(product)),
      target: '_blank',
      rel: 'noopener',
    },
    canOrder ? 'Commander' : 'Nous écrire'
  );

  return el('article', { class: 'card' }, [
    figure,
    el('h3', { class: 'card-title' }, el('a', { href: productUrl(product.slug) }, product.name)),
    el('p', { class: 'card-price' }, price || 'Prix sur demande'),
    el('div', { class: 'card-actions' }, action),
  ]);
}

/* --------------------------------------------------------------- Catalogue */

function mountCatalogue() {
  const grid = document.getElementById('grid');
  if (!grid) return;

  const search = document.getElementById('search');
  const filters = document.getElementById('filters');
  const count = document.getElementById('count');
  const empty = document.getElementById('empty');
  const sort = document.getElementById('sort');

  const params = new URLSearchParams(window.location.search);
  let activeCategory = params.get('categorie') || 'all';
  let query = params.get('q') || '';
  if (search) search.value = query;

  const renderFilters = () => {
    if (!filters) return;
    filters.innerHTML = '';
    const items = [{ id: 'all', name: 'Toutes', n: PRODUCTS.length }].concat(
      CATEGORIES.map((c) => ({ ...c, n: PRODUCTS.filter((p) => p.category === c.id).length }))
    );
    items.forEach((item) => {
      const btn = el(
        'button',
        {
          type: 'button',
          class: `pill${activeCategory === item.id ? ' is-active' : ''}`,
          'aria-pressed': String(activeCategory === item.id),
        },
        [item.name, el('span', { class: 'pill-count' }, String(item.n))]
      );
      btn.addEventListener('click', () => {
        activeCategory = item.id;
        const url = new URL(window.location.href);
        if (item.id === 'all') url.searchParams.delete('categorie');
        else url.searchParams.set('categorie', item.id);
        window.history.replaceState({}, '', url);
        render();
      });
      filters.append(btn);
    });
  };

  const render = () => {
    let list = PRODUCTS.slice();
    if (activeCategory !== 'all') list = list.filter((p) => p.category === activeCategory);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter((p) =>
        [p.name, p.reference, p.short, categoryName(p.category)].join(' ').toLowerCase().includes(q)
      );
    }
    if (sort && sort.value === 'price-asc') list.sort((a, b) => (a.price ?? Infinity) - (b.price ?? Infinity));
    if (sort && sort.value === 'price-desc') list.sort((a, b) => (b.price ?? -1) - (a.price ?? -1));
    if (sort && sort.value === 'name') list.sort((a, b) => a.name.localeCompare(b.name, 'fr'));

    grid.innerHTML = '';
    list.forEach((p) => grid.append(productCard(p)));
    if (count) count.textContent = `${list.length} produit${list.length > 1 ? 's' : ''}`;
    if (empty) empty.hidden = list.length !== 0;
    renderFilters();
  };

  if (search) {
    let timer;
    search.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        query = search.value;
        const url = new URL(window.location.href);
        if (query.trim()) url.searchParams.set('q', query.trim());
        else url.searchParams.delete('q');
        window.history.replaceState({}, '', url);
        render();
      }, 180);
    });
  }
  if (sort) sort.addEventListener('change', render);
  render();
}

/* ------------------------------------------------------------ Product page */

function mountProduct() {
  const root = document.getElementById('product');
  if (!root) return;

  const slug = new URLSearchParams(window.location.search).get('p');
  const product = bySlug(slug || '');

  if (!product) {
    root.innerHTML = `
      <div class="container narrow center">
        <p class="eyebrow">Produit</p>
        <h1>Ce produit n’est plus disponible</h1>
        <p class="muted">Il a peut-être été retiré du catalogue. Parcourez les modèles actuellement proposés.</p>
        <p class="mt-6"><a class="btn btn-primary" href="produits.html">Voir tous les produits</a></p>
      </div>`;
    return;
  }

  document.title = `${product.name} — ${SHOP.name}`;

  const gallery = el('div', { class: 'gallery' });
  const mainImage = el('img', {
    src: `img/${product.images[0]}-960.webp`,
    alt: `${product.name} — ${categoryName(product.category)}`,
    class: 'gallery-main',
    id: 'gallery-main',
  });
  gallery.append(el('div', { class: 'gallery-stage' }, mainImage));
  if (product.images.length > 1) {
    const thumbs = el('div', { class: 'gallery-thumbs' });
    product.images.forEach((key, index) => {
      const btn = el('button', { type: 'button', class: `thumb${index === 0 ? ' is-active' : ''}`, 'aria-label': `Photo ${index + 1}` }, imageTag(key, '', { sizes: '80px' }));
      btn.addEventListener('click', () => {
        mainImage.src = `img/${key}-960.webp`;
        thumbs.querySelectorAll('.thumb').forEach((t) => t.classList.remove('is-active'));
        btn.classList.add('is-active');
      });
      thumbs.append(btn);
    });
    gallery.append(thumbs);
  }

  const price = money(product.price);
  const canOrder = orderable(product.stock);

  const qty = el('input', { type: 'number', min: '1', max: '999', value: '1', id: 'qty', class: 'qty', 'aria-label': 'Quantité souhaitée' });
  const orderLink = el(
    'a',
    { class: 'btn btn-wa btn-block', id: 'order-wa', target: '_blank', rel: 'noopener' },
    'Commander sur WhatsApp'
  );
  const updateOrder = () => {
    orderLink.href = whatsapp(productMessage(product, Math.max(1, Number(qty.value) || 1)));
  };
  qty.addEventListener('input', updateOrder);
  updateOrder();

  const info = el('div', { class: 'product-info' }, [
    el('p', { class: 'crumb' }, [
      el('a', { href: 'index.html' }, 'Accueil'),
      ' / ',
      el('a', { href: 'produits.html' }, 'Nos produits'),
      ' / ',
      el('a', { href: `produits.html?categorie=${product.category}` }, categoryName(product.category)),
    ]),
    el('p', { class: 'eyebrow' }, categoryName(product.category)),
    el('h1', {}, product.name),
    el('p', { class: 'ref' }, `Réf. ${product.reference}${product.demo ? ' · Exemple de démonstration' : ''}`),
    el('p', { class: 'product-price' }, price || 'Prix sur demande'),
    el('p', { class: 'stock' }, [
      el('span', { class: `chip chip-${product.stock}` }, STOCK_LABELS[product.stock]),
      product.stock === 'limite' ? ' — quantités limitées, à confirmer' : '',
      product.stock === 'rupture' ? ' — réassort à confirmer sur WhatsApp' : '',
      product.stock === 'indisponible' ? ' — commande directe désactivée' : '',
    ]),
    el('p', { class: 'product-desc' }, product.description),
    el('div', { class: 'sizes' }, [
      el('p', { class: 'label' }, 'Tailles disponibles'),
      el('ul', { class: 'size-list' }, product.sizes.map((s) => el('li', {}, s))),
    ]),
    el('div', { class: 'qty-row' }, [el('label', { for: 'qty', class: 'label' }, 'Quantité'), qty]),
    el('div', { class: 'cta-stack' }, [
      canOrder ? orderLink : el('button', { class: 'btn btn-ghost btn-block', disabled: '' }, 'Commander'),
      el(
        'a',
        {
          class: 'btn btn-outline btn-block',
          href: whatsapp(wholesaleMessage()),
          target: '_blank',
          rel: 'noopener',
        },
        'Demander un prix de gros'
      ),
      el('p', { class: 'note' }, 'Votre message ouvre WhatsApp avec un texte déjà rédigé. Une demande n’est pas une commande confirmée : nous vous répondons pour valider le prix, la disponibilité et les modalités.'),
      el('a', { class: 'back-link', href: 'produits.html' }, '← Retour au catalogue'),
    ]),
  ]);

  root.innerHTML = '';
  root.append(el('div', { class: 'product-layout container' }, [gallery, info]));

  const related = document.getElementById('related');
  if (related) {
    const others = PRODUCTS.filter((p) => p.slug !== product.slug && p.category === product.category).slice(0, 3);
    const fallback = PRODUCTS.filter((p) => p.slug !== product.slug).slice(0, 3);
    const list = (others.length ? others : fallback).map(productCard);
    related.innerHTML = '';
    list.forEach((card) => related.append(card));
  }
}

/* ------------------------------------------------------------- Home / misc */

function mountFeatured() {
  const grid = document.getElementById('featured');
  if (!grid) return;
  const featured = PRODUCTS.filter((p) => p.featured).slice(0, 4);
  (featured.length ? featured : PRODUCTS.slice(0, 4)).forEach((p) => grid.append(productCard(p)));
}

function mountCategories() {
  const grid = document.getElementById('categories');
  if (!grid) return;
  CATEGORIES.forEach((c) => {
    const n = PRODUCTS.filter((p) => p.category === c.id).length;
    grid.append(
      el('a', { class: 'category-card', href: `produits.html?categorie=${c.id}` }, [
        el('span', { class: 'category-name' }, c.name),
        el('span', { class: 'category-count' }, `${n} produit${n > 1 ? 's' : ''}`),
      ])
    );
  });
}

document.addEventListener('DOMContentLoaded', () => {
  mountChrome();
  mountFeatured();
  mountCategories();
  mountCatalogue();
  mountProduct();
});
