/* ==========================================================================
   Silima Shop — réglages du site
   Modifiez uniquement ce fichier pour mettre le site à jour.
   ========================================================================== */

const SHOP = {
  name: 'Silima Shop',
  // Numéro WhatsApp au format international, sans espaces ni signe +.
  whatsapp: '2250788880307',
  // Affiché sur le site (avec les espaces que vous voulez).
  whatsappDisplay: '+225 07 88 88 03 07',
  phoneDisplay: '+225 07 88 88 03 07',
  phoneLink: '+2250788880307',
  location: 'Adjamé, Abidjan — Côte d\u2019Ivoire',
  currency: 'F CFA',
  // Bandeau d'avertissement en haut du site. Mettez null pour le désactiver.
  demoNotice: 'Démo : produits et prix d\u2019exemple à remplacer avant la mise en ligne.',
  heroTitle: 'De beaux draps pour votre maison.',
  heroText:
    'Découvrez les parures Jimmy disponibles chez Silima Shop. Parcourez les modèles, puis écrivez-nous sur WhatsApp : nous vous confirmons le prix et la disponibilité, pour un achat au détail comme en gros.',
};

/* Catégories affichées dans les filtres (l'ordre compte). */
const CATEGORIES = [
  { id: 'draps-de-lit', name: 'Draps de lit' },
  { id: 'housses-de-couette', name: 'Housses de couette' },
  { id: 'rideaux', name: 'Rideaux' },
  { id: 'autres-articles-textiles', name: 'Autres articles textiles' },
];

/* --------------------------------------------------------------------------
   Produits. Pour ajouter un article, copiez un bloc et adaptez-le.
   - slug      : identifiant unique dans l'adresse (sans espace ni accent)
   - images    : noms de fichiers présents dans /img, sans l'extension ni la taille
                 ex. 'sheets-offwhite' utilise img/sheets-offwhite-480.webp
   - price     : nombre, ou null pour afficher « Prix sur demande »
   - stock     : 'disponible' | 'limite' | 'rupture' | 'indisponible'
   - demo      : true affiche un repère « Démo » sur la fiche
   -------------------------------------------------------------------------- */
const PRODUCTS = [
  {
    slug: 'parure-jimmy-confort-blanc-casse',
    name: 'Parure Jimmy « Confort » — blanc cassé',
    reference: 'DEMO-001',
    category: 'draps-de-lit',
    short: 'Parure de lit unie, coloris blanc cassé.',
    description:
      "Parure de lit unie en coloris blanc cassé, présentée en démonstration. La parure comprend un drap et des taies d\u2019oreiller assorties. Les tailles réellement disponibles sont à confirmer avec la boutique.",
    price: 18500,
    sizes: ['1 place (90×190)', '2 places (140×190)', '2 places (160×200)'],
    images: ['sheets-offwhite', 'sheets-sand'],
    stock: 'disponible',
    featured: true,
    demo: true,
  },
  {
    slug: 'parure-jimmy-cotier-imprime-bleu',
    name: 'Parure Jimmy « Côtier » — imprimé bleu',
    reference: 'DEMO-002',
    category: 'draps-de-lit',
    short: 'Parure imprimée à motif bleu.',
    description:
      'Parure à motif bleu et blanc, présentée en démonstration. Les dimensions, le contenu de la parure et la composition du tissu sont à confirmer avant commande.',
    price: 21000,
    sizes: ['2 places (140×190)', '2 places (160×200)'],
    images: ['sheets-blue', 'pillows'],
    stock: 'limite',
    featured: true,
    demo: true,
  },
  {
    slug: 'drap-housse-jimmy-uni',
    name: 'Drap housse Jimmy — uni',
    reference: 'DEMO-003',
    category: 'draps-de-lit',
    short: 'Drap housse seul. Prix communiqué sur demande.',
    description:
      'Drap housse seul, vendu séparément des taies. Exemple de fiche sans prix affiché : le tarif et les tailles sont communiqués sur WhatsApp.',
    price: null,
    sizes: ['1 place (90×190)', '2 places (140×190)', '2 places (160×200)'],
    images: ['bed-made', 'texture-white'],
    stock: 'disponible',
    featured: false,
    demo: true,
  },
  {
    slug: 'housse-de-couette-jimmy-lin-naturel',
    name: 'Housse de couette Jimmy — lin naturel',
    reference: 'DEMO-004',
    category: 'housses-de-couette',
    short: 'Housse de couette coloris naturel, taies assorties.',
    description:
      'Housse de couette aux tons naturels, présentée avec des taies assorties. Les dimensions disponibles sont à confirmer avec la boutique.',
    price: 24500,
    sizes: ['2 places (200×200)', '2 places (220×240)'],
    images: ['duvet-white', 'duvet-linen'],
    stock: 'disponible',
    featured: true,
    demo: true,
  },
  {
    slug: 'housse-de-couette-sable',
    name: 'Housse de couette « Sable »',
    reference: 'DEMO-005',
    category: 'housses-de-couette',
    short: 'Housse de couette coloris sable.',
    description:
      'Housse de couette coloris sable. Cet article est actuellement en rupture : écrivez-nous pour connaître la date de réassort ou un modèle équivalent.',
    price: 26000,
    sizes: ['2 places (200×200)'],
    images: ['sheets-sand'],
    stock: 'rupture',
    featured: false,
    demo: true,
  },
  {
    slug: 'rideau-jimmy-lin-clair',
    name: 'Rideau Jimmy « Lin clair » — la paire',
    reference: 'DEMO-006',
    category: 'rideaux',
    short: 'Paire de rideaux en coloris lin clair.',
    description:
      'Paire de rideaux en coloris lin clair. Les dimensions, le système de fixation et le degré d\u2019occultation sont à confirmer avec la boutique.',
    price: 15000,
    sizes: ['140 × 260 cm', '200 × 260 cm', 'Sur mesure (nous consulter)'],
    images: ['curtain-linen', 'curtain-sun'],
    stock: 'disponible',
    featured: true,
    demo: true,
  },
  {
    slug: 'rideau-occultant-terre',
    name: 'Rideau occultant « Terre »',
    reference: 'DEMO-007',
    category: 'rideaux',
    short: 'Rideau coloris terre cuite, stock limité.',
    description:
      'Rideau aux tons terre cuite. Stock limité : écrivez-nous pour confirmer la quantité disponible avant de vous déplacer.',
    price: 19500,
    sizes: ['140 × 260 cm', '200 × 260 cm'],
    images: ['curtain-drape'],
    stock: 'limite',
    featured: false,
    demo: true,
  },
  {
    slug: 'taies-oreiller-jimmy-lot-2',
    name: 'Taies d\u2019oreiller Jimmy — lot de 2',
    reference: 'DEMO-008',
    category: 'autres-articles-textiles',
    short: 'Lot de deux taies d\u2019oreiller.',
    description: 'Lot de deux taies d\u2019oreiller, vendu séparément des parures.',
    price: 6000,
    sizes: ['50 × 70 cm'],
    images: ['texture-linen', 'pillows'],
    stock: 'disponible',
    featured: false,
    demo: true,
  },
  {
    slug: 'parure-jimmy-soleil-couchant',
    name: 'Parure Jimmy « Soleil couchant »',
    reference: 'DEMO-009',
    category: 'draps-de-lit',
    short: 'Parure de lit aux tons chauds.',
    description:
      'Parure de lit aux tons chauds. Cet article est momentanément indisponible : la commande directe est désactivée, mais vous pouvez nous écrire pour être prévenu du retour en stock.',
    price: 22000,
    sizes: ['2 places (140×190)'],
    images: ['bed-sunrise', 'linen-room'],
    stock: 'indisponible',
    featured: false,
    demo: true,
  },
];
