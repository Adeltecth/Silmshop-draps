# Crédits des photographies de démonstration

Ces photos sont des **exemples** : elles ne représentent pas les produits réels de Silima
Shop et doivent être remplacées avant la mise en ligne.

| Fichier source (`silima-shop/assets-source/`) | Origine | Licence |
|---|---|---|
| `hero-bed.jpg` | Unsplash — photo `1614590370666-22e7beade570` | Licence Unsplash |
| `about-bedroom.jpg` | Unsplash — photo `1619001904482-b0628b82b3e9` | Licence Unsplash |
| `duvet-linen.jpg` | Unsplash — photo `1615800001718-73ba40557cb3` | Licence Unsplash |
| `sheets-white.jpg` | Pexels — photo 3755590 | Licence Pexels |
| `sheets-sand.jpg` | Pexels — photo 4045542 | Licence Pexels |
| `sheets-blue.jpg` | Pexels — photo 7765000 | Licence Pexels |
| `sheets-offwhite.jpg` | Pexels — photo 10061393 | Licence Pexels |
| `bed-sunrise.jpg` | Pexels — photo 33312315 | Licence Pexels |
| `duvet-white.jpg` | Pexels — photo 3030684 | Licence Pexels |
| `curtain-linen.jpg` | Pexels — photo 6125630 | Licence Pexels |
| `curtain-sun.jpg` | Pexels — photo 910458 | Licence Pexels |
| `curtain-drape.jpg` | Pexels — photo 32763234 | Licence Pexels |
| `pillows.jpg` | Pexels — photo 212269 | Licence Pexels |
| `texture-linen.jpg` | Pexels — photo 5629140 | Licence Pexels |
| `texture-white.jpg` | Pexels — photo 14510648 | Licence Pexels |
| `bed-made.jpg` | Pexels — photo 4045539 | Licence Pexels |
| `linen-room.jpg` | Pexels — photo 30926942 | Licence Pexels |

Licences : [Pexels](https://www.pexels.com/license/) et
[Unsplash](https://unsplash.com/license) — usage gratuit, y compris commercial, sans
attribution obligatoire.

## Remplacer par les photos de la boutique

1. Photographier chaque modèle à la lumière du jour, sans flash, cadrage vertical (4:5).
2. Exporter en WebP, deux largeurs : 480 px et 960 px.
3. Nommer `mon-produit-480.webp` et `mon-produit-960.webp`, placer dans `img/`.
4. Référencer `mon-produit` dans `assets/products.js` (champ `images`).
